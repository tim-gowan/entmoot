#include "tree_sitter/parser.h"

#include <wctype.h>

enum TokenType {
    AUTOMATIC_SEMICOLON,
    TEMPLATE_CHARS,
    TERNARY_QMARK,
    HTML_COMMENT,
    LOGICAL_OR,
    ESCAPE_SEQUENCE,
    REGEX_PATTERN,
    JSX_TEXT,
    USING_KEYWORD,
    AWAIT_USING_KEYWORD,
    FUNCTION_SIGNATURE_AUTOMATIC_SEMICOLON,
    ERROR_RECOVERY,
};

static void advance(TSLexer *lexer) { lexer->advance(lexer, false); }

static void skip(TSLexer *lexer) { lexer->advance(lexer, true); }

static bool scan_template_chars(TSLexer *lexer) {
    lexer->result_symbol = TEMPLATE_CHARS;
    for (bool has_content = false;; has_content = true) {
        lexer->mark_end(lexer);
        switch (lexer->lookahead) {
            case '`':
                return has_content;
            case '\0':
                return false;
            case '$':
                advance(lexer);
                if (lexer->lookahead == '{') {
                    return has_content;
                }
                break;
            case '\\':
                return has_content;
            default:
                advance(lexer);
        }
    }
}

static bool scan_asi_trivia(TSLexer *lexer, bool allow_inline_comment, bool *newline, bool *scanned_comment) {
    for (;;) {
        int32_t c = lexer->lookahead;
        bool line_end = c == '\n' || c == '\r' || c == 0x2028 || c == 0x2029;
        if (line_end || iswspace(c) || c == 0xfeff) {
            *newline |= line_end;
            skip(lexer);
        } else if (c == '/') {
            skip(lexer);
            if (lexer->lookahead == '/') {
                // Let an inline line-comment remain inside its existing statement.
                // Its terminating newline will be scanned after the extra token.
                if (!*newline && !allow_inline_comment) return false;
                *scanned_comment = true;
                do {
                    skip(lexer);
                    c = lexer->lookahead;
                } while (c && c != '\n' && c != '\r' && c != 0x2028 && c != 0x2029);
            } else if (lexer->lookahead == '*') {
                *scanned_comment = true;
                skip(lexer);
                bool closed = false;
                while (lexer->lookahead) {
                    c = lexer->lookahead;
                    *newline |= c == '\n' || c == '\r' || c == 0x2028 || c == 0x2029;
                    skip(lexer);
                    if (c == '*' && lexer->lookahead == '/') {
                        skip(lexer);
                        closed = true;
                        break;
                    }
                }
                if (!closed) return false;
            } else {
                // A division operator cannot start an automatically separated statement.
                return false;
            }
        } else {
            return true;
        }
    }
}

static bool scan_automatic_semicolon(TSLexer *lexer, const bool *valid_symbols, bool *scanned_comment) {
    lexer->result_symbol = AUTOMATIC_SEMICOLON;
    lexer->mark_end(lexer);
    bool newline = false;
    if (!scan_asi_trivia(lexer, false, &newline, scanned_comment)) return false;
    if (!newline && *scanned_comment) return false;
    if (lexer->lookahead == 0) return true;
    if (lexer->lookahead == '}') {
        // Preserve the existing typed-object-pattern ambiguity control.
        do { skip(lexer); } while (iswspace(lexer->lookahead));
        if (lexer->lookahead == ':') return valid_symbols[LOGICAL_OR];
        return true;
    }
    if (!newline) return false;

    switch (lexer->lookahead) {
        case '`':
        case ',':
        case '.':
        case ';':
        case '*':
        case '%':
        case '>':
        case '<':
        case '=':
        case '?':
        case '^':
        case '|':
        case '&':
        case '/':
        case ':':
            return false;

        case '{':
            if (valid_symbols[FUNCTION_SIGNATURE_AUTOMATIC_SEMICOLON]) {
                return false;
            }
            break;

            // Don't insert a semicolon before a '[' or '(', unless we're parsing
            // a type. Detect whether we're parsing a type or an expression using
            // the validity of a binary operator token.
        case '(':
        case '[':
            if (valid_symbols[LOGICAL_OR]) {
                return false;
            }
            break;

            // Insert a semicolon before `--` and `++`, but not before binary `+` or `-`.
        case '+':
            skip(lexer);
            return lexer->lookahead == '+';
        case '-':
            skip(lexer);
            return lexer->lookahead == '-';

            // Don't insert a semicolon before `!=`, but do insert one before a unary `!`.
        case '!':
            skip(lexer);
            return lexer->lookahead != '=';

            // Don't insert a semicolon before `in` or `instanceof`, but do insert one
            // before an identifier.
        case 'i':
            skip(lexer);

            if (lexer->lookahead != 'n') {
                return true;
            }
            skip(lexer);

            if (!iswalpha(lexer->lookahead)) {
                return false;
            }

            for (unsigned i = 0; i < 8; i++) {
                if (lexer->lookahead != "stanceof"[i]) {
                    return true;
                }
                skip(lexer);
            }

            if (!iswalpha(lexer->lookahead)) {
                return false;
            }
            break;
    }

    return true;
}

static bool scan_ternary_qmark(TSLexer *lexer) {
    for (;;) {
        if (!iswspace(lexer->lookahead)) {
            break;
        }
        skip(lexer);
    }

    if (lexer->lookahead == '?') {
        advance(lexer);

        /* Optional chaining. */
        if (lexer->lookahead == '?' || lexer->lookahead == '.') {
            return false;
        }

        lexer->mark_end(lexer);
        lexer->result_symbol = TERNARY_QMARK;

        /* TypeScript optional arguments contain the ?: sequence, possibly
           with whitespace. */
        for (;;) {
            if (!iswspace(lexer->lookahead)) {
                break;
            }
            advance(lexer);
        }

        if (lexer->lookahead == ':' || lexer->lookahead == ')' || lexer->lookahead == ',') {
            return false;
        }

        if (lexer->lookahead == '.') {
            advance(lexer);
            if (iswdigit(lexer->lookahead)) {
                return true;
            }
            return false;
        }
        return true;
    }
    return false;
}

static bool scan_closing_comment(TSLexer *lexer) {
    while (iswspace(lexer->lookahead) || lexer->lookahead == 0x2028 || lexer->lookahead == 0x2029) {
        skip(lexer);
    }

    const char *comment_start = "<!--";
    const char *comment_end = "-->";

    if (lexer->lookahead == '<') {
        for (unsigned i = 0; i < 4; i++) {
            if (lexer->lookahead != comment_start[i]) {
                return false;
            }
            advance(lexer);
        }
    } else if (lexer->lookahead == '-') {
        for (unsigned i = 0; i < 3; i++) {
            if (lexer->lookahead != comment_end[i]) {
                return false;
            }
            advance(lexer);
        }
    } else {
        return false;
    }

    while (lexer->lookahead != 0 && lexer->lookahead != '\n' && lexer->lookahead != 0x2028 &&
           lexer->lookahead != 0x2029) {
        advance(lexer);
    }

    lexer->result_symbol = HTML_COMMENT;
    lexer->mark_end(lexer);

    return true;
}

static bool scan_jsx_text(TSLexer *lexer) {
    // saw_text will be true if we see any non-whitespace content, or any whitespace content that is not a newline and
    // does not immediately follow a newline.
    bool saw_text = false;
    // at_newline will be true if we are currently at a newline, or if we are at whitespace that is not a newline but
    // immediately follows a newline.
    bool at_newline = false;

    while (lexer->lookahead != 0 && lexer->lookahead != '<' && lexer->lookahead != '>' && lexer->lookahead != '{' &&
           lexer->lookahead != '}' && lexer->lookahead != '&') {
        bool is_wspace = iswspace(lexer->lookahead);
        if (lexer->lookahead == '\n') {
            at_newline = true;
        } else {
            // If at_newline is already true, and we see some whitespace, then it must stay true.
            // Otherwise, it should be false.
            //
            // See the table below to determine the logic for computing `saw_text`.
            //
            // |------------------------------------|
            // | at_newline | is_wspace | saw_text  |
            // |------------|-----------|-----------|
            // | false (0)  | false (0) | true  (1) |
            // | false (0)  | true  (1) | true  (1) |
            // | true  (1)  | false (0) | true  (1) |
            // | true  (1)  | true  (1) | false (0) |
            // |------------------------------------|

            at_newline &= is_wspace;
            if (!at_newline) {
                saw_text = true;
            }
        }

        advance(lexer);
    }

    lexer->result_symbol = JSX_TEXT;
    return saw_text;
}


// Look ahead without widening the keyword span. A resource declaration cannot
// cross a line terminator, including one inside a block comment.
static bool resource_line_end(int32_t c) {
    return c == '\n' || c == '\r' || c == 0x2028 || c == 0x2029;
}

static bool resource_gap(TSLexer *lexer) {
    bool separated = false;
    for (;;) {
        if (resource_line_end(lexer->lookahead)) return false;
        if (iswspace(lexer->lookahead) || lexer->lookahead == 0xfeff) {
            separated = true;
            advance(lexer);
        } else if (lexer->lookahead == '/') {
            advance(lexer);
            if (lexer->lookahead != '*') return false;
            advance(lexer);
            bool closed = false;
            while (lexer->lookahead) {
                if (resource_line_end(lexer->lookahead)) return false;
                if (lexer->lookahead == '*') {
                    advance(lexer);
                    if (lexer->lookahead == '/') {
                        advance(lexer);
                        closed = true;
                        break;
                    }
                } else {
                    advance(lexer);
                }
            }
            if (!closed) return false;
            separated = true;
        } else {
            return separated;
        }
    }
}

static bool scan_resource_keyword(TSLexer *lexer, bool await_using) {
    const char *keyword = await_using ? "await" : "using";
    for (unsigned i = 0; keyword[i]; ++i) {
        if (lexer->lookahead != keyword[i]) return false;
        advance(lexer);
    }
    lexer->mark_end(lexer);
    if (!resource_gap(lexer)) return false;
    if (await_using) {
        const char *using_keyword = "using";
        for (unsigned i = 0; using_keyword[i]; ++i) {
            if (lexer->lookahead != using_keyword[i]) return false;
            advance(lexer);
        }
        if (!resource_gap(lexer)) return false;
    }
    int32_t c = lexer->lookahead;
    if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '$' || c == '\\' || c > 127)) return false;
    lexer->result_symbol = await_using ? AWAIT_USING_KEYWORD : USING_KEYWORD;
    return true;
}

static inline bool external_scanner_scan(void *payload, TSLexer *lexer, const bool *valid_symbols) {
    if (valid_symbols[TEMPLATE_CHARS]) {
        if (valid_symbols[AUTOMATIC_SEMICOLON]) {
            return false;
        }
        return scan_template_chars(lexer);
    }

    if (valid_symbols[JSX_TEXT] && scan_jsx_text(lexer)) {
        return true;
    }

    if (!valid_symbols[AUTOMATIC_SEMICOLON] && (valid_symbols[USING_KEYWORD] || valid_symbols[AWAIT_USING_KEYWORD])) {
        while (iswspace(lexer->lookahead) || lexer->lookahead == 0xfeff) skip(lexer);
        if (valid_symbols[USING_KEYWORD] && lexer->lookahead == 'u') {
            return scan_resource_keyword(lexer, false);
        }
        if (valid_symbols[AWAIT_USING_KEYWORD] && lexer->lookahead == 'a') {
            return scan_resource_keyword(lexer, true);
        }
    }

    if (valid_symbols[AUTOMATIC_SEMICOLON] || valid_symbols[FUNCTION_SIGNATURE_AUTOMATIC_SEMICOLON]) {
        bool scanned_comment = false;
        bool ret = scan_automatic_semicolon(lexer, valid_symbols, &scanned_comment);
        if (!ret && !scanned_comment && valid_symbols[TERNARY_QMARK] && lexer->lookahead == '?') {
            return scan_ternary_qmark(lexer);
        }
        return ret;
    }
    if (valid_symbols[TERNARY_QMARK]) {
        return scan_ternary_qmark(lexer);
    }

    if (valid_symbols[HTML_COMMENT] && !valid_symbols[LOGICAL_OR] && !valid_symbols[ESCAPE_SEQUENCE] &&
        !valid_symbols[REGEX_PATTERN]) {
        return scan_closing_comment(lexer);
    }

    return false;
}
